Connect the Infinite Rotation Sensor to A0 pin of Arduino.
Connect the LED module to D3 pin of Ardino.
Upload the demo code to Arduino board.
Turn on the serial monitor of arduino IDE, and then you can fine the degree of the sensor,
and the greater the angle, the higher the brightness of the LED.