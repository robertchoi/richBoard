The demo code for 1.3inch OLED module is in the directory of
\Adafruit_SH1106\examples\sh1106_128x64_i2c