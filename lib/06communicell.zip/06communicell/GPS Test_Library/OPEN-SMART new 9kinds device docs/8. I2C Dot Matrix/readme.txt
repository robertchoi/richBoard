The two libraries should be put in the directory of libraries of your Arduino IDE.

Please try this demo code first:
\Adafruit_LED_Backpack_Library\examples\matrix8x8